<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbname";
$conn = new PDO("sqlsrv:Server=$servername;Database=$dbname", $username, $password);
if (!$conn) {    
    die("Connection failed: " . print_r(sqlsrv_errors(), true));}
?>