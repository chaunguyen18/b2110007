<!DOCTYPE HTML>
<html> 
<body>
    <!-- tao form nhap du lieu  -->
    <form action="major_save.php" method="post">
        ID: <input type="text" name="id"><br>
        Name Major: <input type="text" name="name_major"><br>
        <input type="submit">
    </form>
</body>
</html>