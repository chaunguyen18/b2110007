<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "dbname";
$conn = oci_connect($username, $password, $servername / $database);
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
?>